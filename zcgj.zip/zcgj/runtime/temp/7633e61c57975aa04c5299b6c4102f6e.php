<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:72:"D:\phpStudy\WWW\zcgj\public/../application/index\view\publics\login.html";i:1541126787;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>登录</title>
		<link rel="stylesheet" href="/static/ace/css/bootstrap.css" />
		<link rel="stylesheet" href="/static/ace/css/login.css" />
	</head>
	<body class="login_bg">
		<img src="/static/ace/img/logo_zc.png" class="logo"/>
		<div class="login">
			<h1>登录</h1>
			<input placeholder="请输入手机号"/>
			<input placeholder="请输入密码" type="password"/>
			<button onclick="login()">登录</button>
			<div class="login_bottom"><span class="wjmm">忘记密码</span></div>
		</div>
		<div class="forgot_pass dis_none">
			<h1>忘记密码</h1>
			<input placeholder="请输入手机号"/>
			<input placeholder="请输入验证码" class="code"/>
			<span>发送验证码</span>
			<button>找回密码</button>
			<div class="login_bottom"><font class="ljdl">立即登录</font></div>
		</div>
	</body>
	<script type="text/javascript" src="/static/ace/js/jquery.min.js" ></script>
	<script type="text/javascript" src="/static/ace/js/bootstrap.min.js" ></script>
	<script type="text/javascript" src="/static/ace/js/common.js" ></script>
	<script>
		function login(){
			window.location = 'home.html';
			document.cookie="sata=1";
		}
	</script>
</html>
