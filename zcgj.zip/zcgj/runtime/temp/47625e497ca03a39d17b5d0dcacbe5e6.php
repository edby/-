<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:74:"D:\phpStudy\WWW\zcgj\public/../application/index\view\publics\userreg.html";i:1541126713;}*/ ?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8" />
		<title>注册</title>
		<link rel="stylesheet" href="/static/ace/css/bootstrap.css" />
		<link rel="stylesheet" href="/static/ace/css/login.css" />
	</head>
	<body class="login_bg">
		<img src="/static/ace/img/logo_zc.png" class="logo"/>
		<div class="forgot_pass regis_body">
			<h1>注册</h1>
			<input placeholder="请输入手机号"/>
			<input placeholder="请输入验证码" class="code"/>
			<span>发送验证码</span>
			<input placeholder="请输入密码" type="password"/>
			<input placeholder="请再次输入密码" type="password"/>
			<button>找回密码</button>
			<div class="login_bottom"></div>
		</div>
	</body>
	<script type="text/javascript" src="/static/ace/js/jquery.min.js" ></script>
	<script type="text/javascript" src="/static/ace/js/bootstrap.min.js" ></script>
	<script type="text/javascript" src="/static/ace/js/common.js" ></script>
</html>
