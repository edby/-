<?php

//配置文件
return [
    /* 密码加密 */
    'DATA_AUTH_KEY' => 'Ur?j!AY+"y3DvCKa%6s4WXVBT',
];
