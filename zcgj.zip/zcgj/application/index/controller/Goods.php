<?php
namespace app\index\controller;

use app\common\controller\Base;
use think\Request;

class Goods extends Base
{
	
	/**
	 * controller 商城首页
	 */
	public function index(){
		
		return $this -> fetch();
	}
	
	/**
	 * controller 商品分类
	 */
	public function classify(){
		
		return $this -> fetch();
	}
	
	/**
	 * controller 优惠专区
	 */
	public function preferential(){
		
		return $this -> fetch();
	}
	
	/**
	 * controller 特色专区
	 */
	public function feature(){
		
		return $this -> fetch();
	}
	
	/**
	 * controller 商品详情
	 */
	public function detail(){
		
		return $this -> fetch();
	}
	
	/**
	 * controller 激活券
	 */
	public function activate(){
		
		return $this -> fetch();
	}
	
	/**
	 * controller 修改券
	 */
	public function change(){
		
		return $this -> fetch();
	}
	
	/**
	 * controller 手续费券
	 */
	public function tip(){
		
		return $this -> fetch();
	}
	
	/**
	 * controller 入驻券
	 */
	public function enter(){
		
		return $this -> fetch();
	}
	
	/**
	 * controller 结算
	 */
	public function clear(){
		
		return $this -> fetch();
	}
	
	/**
	 * controller 购物车
	 */
	public function car(){
		
		return $this -> fetch();
	}
}
