
function addShow() {
    
}
$('#minus').click(function () {
    var num = $('#goodsNum').val();
    if(num > 1) {
        $('#goodsNum').val(num-1);
    }
});
var inentory = $('#inventory').text();
if(inentory > 0) {
    $('#goodsNum').val(1);
}else {
    $('#goodsNum').val(0);
}
$('#add').click(function () {
    var num = $('#goodsNum').val();
    num++;
    if(num <= inentory) {
        $('#goodsNum').val(num);
    }
});

function toTrolley() {
    // layer.msg('已加入购物车');
    layer.confirm('已加入购物车', {
        btn: ['去购物车结算','再逛逛'] //按钮
    }, function(index){
        layer.close(index);
        window.location.href = 'shopCart.html';
    });
}
