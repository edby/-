$(function() {
	//返回顶部
	$(window).scroll(function() {
		if($(this).scrollTop() >= 300) {
			$(".demo_bb").fadeIn();
		} else {
			$(".demo_bb").fadeOut();
		}
	});
	$(function() {
		$(".demo_bb").click(function() {
			$("html,body").animate({
				scrollTop: 0
			}, 600);
		});
	});
	//币种交易下拉菜单；
	var tog = false;
	$('.cur_tran_drop').click(function() {
		tog = !tog;
		if(tog == true) {
			$(this).attr('src', '/static/ace/img/cur_trans_2.png');
			$('.cur_tran_menu').show();
		} else {
			$(this).attr('src', '/static/ace/img/cur_trans_1.png');
			$('.cur_tran_menu').hide();
		}
	});
	//币种切换样式；
	$('.cur_tran_menu li').click(function(){
		var curtit = $(this).children('span').html();
		$('.cur_tran_tit_l span').html(curtit);
		$(this).children('span').addClass('cor_blue');
		$('.cur_tran_menu li span').not($(this).children('span')).removeClass('cor_blue');
		$('.cur_tran_menu').hide();
		$('.cur_tran_drop').attr('src','/static/ace/img/cur_trans_1.png');
		tog = !tog; //修改全局tog;
	});
	//下载中心交互；
	$('.xnb_down').click(function() {
		$(this).addClass('down_cen_l_act');
		$('.new_cur_apl').removeClass('down_cen_l_act');
		$('.xnb_down_body').show();
		$('.new_cur_apl_body').hide();
	});
	$('.new_cur_apl').click(function() {
		$(this).addClass('down_cen_l_act');
		$('.xnb_down').removeClass('down_cen_l_act');
		$('.new_cur_apl_body').show();
		$('.xnb_down_body').hide();
	});
	//k线图周期切换;
	$('.period span').click(function(){
		$(this).addClass('period_act');
		$('.period span').not($(this)).removeClass('period_act');
	});
});