//结算
/*
 * 结算的时候先判断有没有选择商品
 * 然后遍历选中商品的input
 * 并把选中input的value存储到array数组中
 * 最后跳转到结算页面
 */
function clearing() {
    var length = $('input[name="shop"]:checked').length;
    var array = [];
    if(length <= 0) {
        layer.alert('请选择要购买的商品');
    }else {
        $('input[name="shop"]:checked').each(function () {
            array.push($(this).val());
        });
        console.log(array);
        window.location.href = 'clear.html';
    }
}
//全选
$('input[name="all"]').click(function () {
    var ids = this.checked;
    $('input[name="all"]').each(function () {
        this.checked = ids;
    });
    $('input[name="shop"]').each(function () {
        this.checked = ids;
    });
});
$('input[name="shop"]').click(function () {
    var length = $('input[name="shop"]:checked').length;
    var len = $('input[name="shop"]').length;
    if(length === len) {
        $('input[name="all"]').each(function () {
            this.checked = true;
        });
    }else {
        $('input[name="all"]').each(function () {
            this.checked = false;
        });
    }
});
//商品数量增减
function cart_menus(index) {
    var num = $(index).next('input').val();
    if(num > 0) {
        num--;
        $(index).next('input').val(num);
    }
}
function cart_add(index) {
    var num = $(index).prev('input').val();
    if(num < 5) {
        num++;
        $(index).prev('input').val(num);
    }
}
//删除
function del() {
    layer.confirm('确定删除该商品？', {
        btn: ['确定','取消'] //按钮
    }, function(){
        layer.msg('已删除');
    });
}