
//增减商品数量
function clear_menus() {
    var num = $('#clearNum').val();
    if(num > 0) {
        num--;
        $('#clearNum').val(num);
    }
}
function clear_add() {
    var num = $('#clearNum').val();
    if(num < 5) {
        num++;
        $('#clearNum').val(num);
    }
}
// 提交订单
function submit_order() {
    $('.payment').show();
}
//输入密码
function cancel_pay() {
    $('.payment').hide();
}
function payment() {
    var pwd = $('#pay_pwd').val();
    if(pwd.length < 6) {
        layer.alert('支付密码错误！');
    }else {
        $('.payment').hide();
        $('#pay_pwd').val('');
        layer.confirm('支付成功！', {
            btn: ['查看订单','继续浏览']
        }, function(){
            window.location.href = 'userCenter.html';
        }, function(){
            window.location.href = 'store.html';
        });
    }
}