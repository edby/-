$(function(){
	//登录->忘记密码切换;
	$('.wjmm').click(function(){
		$('.login').hide();
		$('.forgot_pass').show();
	});
	$('.ljdl').click(function(){
		$('.login').show();
		$('.forgot_pass').hide();
	});	
})
//判断顶部导航状态
function setNav(i){
	$('.top_nav_r li').eq(i).addClass('top_nav_act');
}