// 实例化layui
layui.use(['layer', 'form'], function(){
    var layer = layui.layer,form = layui.form;
});

//众城商城导航
function setStoreNav(i){
    $('.store_nav_r li a').eq(i).addClass('adtive');
}

//搜索
function searchBtn() {
    var text = $('#search').val();
    alert(text);
}
//轮播图定时轮播
$('.carousel').carousel({
    interval: 5000
});
//购买商品
function buy() {
    window.location.href = 'clear.html';
}

//激活券
function ticket() {
    layer.confirm('确定购买？', {
        btn: ['确定','取消'] //按钮
    }, function(index){
        layer.close(index);
        $('.activate_now').show();
    });
}
function cancel() {
    $('.activate_now').hide();
}
function activate_now() {
    layer.msg('立即激活！');
    $('.activate_now').hide();
}

function item() {
    window.location.href = 'item.html';
}

//入驻券
function enter_tic() {
    layer.confirm('确定购买？', {
        btn: ['确定','取消'] //按钮
    }, function(index){
        layer.close(index);
        $('.activate_now').show();
    });
}
function enter_now() {
    layer.msg('立即入驻');
    $('.activate_now').hide();
}

//修改券
function changes() {
    layer.confirm('确定购买？', {
        btn: ['确定','取消'] //按钮
    }, function(index){
        layer.close(index);
        layer.alert('购买成功！');
    });
}

//手续费
function tip() {
    layer.confirm('确定购买？', {
        btn: ['确定','取消'] //按钮
    }, function(index){
        layer.close(index);
        layer.alert('购买成功！');
    });
}